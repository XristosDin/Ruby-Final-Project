Category.create([
  { name: "Μάθημα" },
  { name: "Εργασία" },
  { name: "Ομάδα" },
  { name: "Γενικά" }
])
