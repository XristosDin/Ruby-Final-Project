class Api::V1::TodoItemsController < Api::V1::BaseController
  before_action :set_todo

  def show
    render json: @todo.todo_items.find(params[:id])
  end

  def create
    item = @todo.todo_items.build(item_params)
    item.save
    render json: item, status: :created
  end

  def update
    item = @todo.todo_items.find(params[:id])
    item.update(item_params)
    render json: item
  end

  def destroy
    item = @todo.todo_items.find(params[:id])
    item.destroy
    render json: { message: "Deleted" }
  end

  private

  def set_todo
    @todo = @current_user.todos.find(params[:todo_id])
  end

  def item_params
    params.require(:todo_item).permit(:content, :completed)
  end
end
