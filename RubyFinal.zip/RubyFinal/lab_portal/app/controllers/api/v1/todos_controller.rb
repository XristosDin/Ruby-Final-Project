class Api::V1::TodosController < Api::V1::BaseController
  def index
    todos = @current_user.todos
    render json: todos
  end

  def create
    todo = @current_user.todos.build(todo_params)

    if todo.save
      render json: todo, status: :created
    else
      render json: { errors: todo.errors.full_messages }, status: :unprocessable_entity
    end
  end

  private

  def todo_params
    params.permit(:title)
  end
end



