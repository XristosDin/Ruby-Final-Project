class Item < ApplicationRecord
  belongs_to :todo
end
