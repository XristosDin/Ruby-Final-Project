Rails.application.routes.draw do
  devise_for :users

  root "posts#index"

  resources :posts
  resources :categories
  resources :contacts, only: [:index, :create, :destroy]
  resources :private_messages, only: [:index, :create]

  namespace :api do
    namespace :v1 do
      post "/signup",      to: "auth#signup"
      post "/auth/login",  to: "auth#login"
      get  "/auth/logout", to: "auth#logout"

      resources :todos do
        resources :todo_items, path: "items"
      end
    end
  end
end

